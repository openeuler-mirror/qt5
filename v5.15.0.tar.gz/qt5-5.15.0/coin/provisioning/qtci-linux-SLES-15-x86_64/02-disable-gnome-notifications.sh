#!/usr/bin/env bash

# shellcheck source=../common/linux/disable-notifications.sh
source "${BASH_SOURCE%/*}/../common/linux/disable-notifications.sh"
