. "$PSScriptRoot\..\common\windows\disable-windows-updates.ps1"
