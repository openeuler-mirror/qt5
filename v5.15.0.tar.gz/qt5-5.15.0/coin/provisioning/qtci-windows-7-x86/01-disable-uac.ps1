. "$PSScriptRoot\..\common\windows\disable-uac.ps1"
