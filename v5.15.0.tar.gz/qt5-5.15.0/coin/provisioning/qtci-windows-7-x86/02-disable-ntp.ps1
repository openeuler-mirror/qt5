. "$PSScriptRoot\..\common\windows\disable-ntp.ps1"
