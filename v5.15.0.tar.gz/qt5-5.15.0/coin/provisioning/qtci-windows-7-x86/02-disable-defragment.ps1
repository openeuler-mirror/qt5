. "$PSScriptRoot\..\common\windows\disable-defragment.ps1"
