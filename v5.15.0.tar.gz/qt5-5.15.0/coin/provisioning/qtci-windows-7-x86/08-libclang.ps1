. "$PSScriptRoot\..\common\windows\libclang.ps1" 32 mingw
