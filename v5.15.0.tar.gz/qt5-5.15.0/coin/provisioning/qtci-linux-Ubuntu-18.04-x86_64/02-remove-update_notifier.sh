#!/usr/bin/env bash

# shellcheck source=../common/linux/remove-update_notifier.sh
source "${BASH_SOURCE%/*}/../common/linux/remove-update_notifier.sh"
