#!/usr/bin/env bash

# shellcheck source=../common/linux/remove-apport.sh
source "${BASH_SOURCE%/*}/../common/linux/remove-apport.sh"
