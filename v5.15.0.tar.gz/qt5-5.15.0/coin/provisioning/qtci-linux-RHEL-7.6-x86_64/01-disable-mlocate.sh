#!/usr/bin/env bash
BASEDIR=$(dirname "$0")
# shellcheck source=../common/linux/disable-mlocate.sh
"$BASEDIR/../common/linux/disable-mlocate.sh"
