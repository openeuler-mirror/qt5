. "$PSScriptRoot\..\common\windows\install-protobuf.ps1"

