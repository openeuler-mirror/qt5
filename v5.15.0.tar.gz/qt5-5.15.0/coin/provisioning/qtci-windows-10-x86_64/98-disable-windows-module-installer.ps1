. "$PSScriptRoot\..\common\windows\disable-windows-module-installer.ps1"
