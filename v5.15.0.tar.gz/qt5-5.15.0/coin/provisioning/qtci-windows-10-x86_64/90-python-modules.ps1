# Needed by packaging scripts
C:\Python36\Scripts\pip3 install bs4
C:\Python36\Scripts\pip3 install sh
