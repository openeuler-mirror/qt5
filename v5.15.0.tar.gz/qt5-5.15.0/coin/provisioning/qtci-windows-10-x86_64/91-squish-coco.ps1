 "$PSScriptRoot\..\common\windows\squish-coco.ps1"

