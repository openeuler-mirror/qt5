#!/usr/bin/env bash

sudo apt-get purge apport -y
