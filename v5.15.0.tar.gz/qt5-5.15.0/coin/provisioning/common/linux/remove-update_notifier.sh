#!/usr/bin/env bash

sudo apt -q -y remove update-notifier update-manager python3-distupgrade python3-update-manager ubuntu-release-upgrader-core update-manager-core
