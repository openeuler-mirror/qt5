. "$PSScriptRoot\..\common\windows\win10sdk.ps1"
