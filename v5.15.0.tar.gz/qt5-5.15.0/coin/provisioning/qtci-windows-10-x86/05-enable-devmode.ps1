. "$PSScriptRoot\..\common\windows\win10-enable-devmode.ps1"
