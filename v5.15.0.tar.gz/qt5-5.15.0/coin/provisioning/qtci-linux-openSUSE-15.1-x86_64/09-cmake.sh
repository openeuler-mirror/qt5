#!/usr/bin/env bash

set -ex

"$(dirname "$0")/../common/linux/cmake_linux.sh"
