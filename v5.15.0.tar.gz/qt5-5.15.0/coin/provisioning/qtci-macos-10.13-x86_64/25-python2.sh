#!/usr/bin/env bash
set -ex

# shellcheck source=../common/macos/python2.sh
source "${BASH_SOURCE%/*}/../common/macos/python2.sh"
