#!/bin/sh

"$(dirname "$0")"/../common/macos/disable-notifications_and_warnings.sh
